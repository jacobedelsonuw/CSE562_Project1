//
//  Agentic_AiTests.swift
//  Agentic AiTests
//
//  Created by Jacob Edelson on 4/7/25.
//

import Testing

struct Agentic_AiTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
