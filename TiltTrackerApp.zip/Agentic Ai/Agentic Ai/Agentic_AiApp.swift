//
//  Agentic_AiApp.swift
//  Agentic Ai
//
//  Created by Jacob Edelson on 4/7/25.
//

import SwiftUI

@main
struct Agentic_AiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
