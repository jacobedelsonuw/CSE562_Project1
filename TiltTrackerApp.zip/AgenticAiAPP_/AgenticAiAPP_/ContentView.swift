import SwiftUI

#if os(iOS)
import CoreMotion
import Charts
#endif

struct TiltDataPoint: Identifiable {
    let id = UUID()
    let time: Double
    let accelTilt: Double
    let gyroTilt: Double
    let filteredTilt: Double
}

enum AppTab {
    case part1
    case part2
    case demo
}

struct ContentView: View {
    @StateObject var motionManager = MotionManager()
    @State private var selectedTab = 0
    @State private var selectedMethod = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            // Part 1: Bias and Noise Estimation
            BiasEstimationView(motionManager: motionManager)
                .tabItem {
                    Label("Part 1: Calibration", systemImage: "1.circle")
                }
                .tag(0)
            
            // Part 2: Comparison of Methods
            ComparisonView(motionManager: motionManager, selectedMethod: $selectedMethod)
                .tabItem {
                    Label("Part 2: Comparison", systemImage: "2.circle")
                }
                .tag(1)
            
            // Demo: Real-time Tilt
            DemoView(motionManager: motionManager)
                .tabItem {
                    Label("Demo", systemImage: "rotate.3d")
                }
                .tag(2)
        }
        .onChange(of: selectedTab) { newValue in
            // Stop measurements when switching tabs
            motionManager.stopMeasurement()
        }
    }
}

// Part 1: Bias and Noise Estimation View
struct BiasEstimationView: View {
    @ObservedObject var motionManager: MotionManager
    
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Calibration")) {
                    Button("Estimate Bias & Noise (100 samples)") {
                        motionManager.estimateBiasAndNoise(sampleCount: 100)
                    }
                    .disabled(motionManager.isRunning)
                    
                    Text(motionManager.estimationMessageString)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                if motionManager.hasBiasData {
                    Section(header: Text("Bias Estimates")) {
                        // Accel Bias
                        HStack {
                            Text("Accel X Bias:")
                            Spacer()
                            Text(String(format: "%.6f", motionManager.accelXBias))
                        }
                        HStack {
                            Text("Accel Y Bias:")
                            Spacer()
                            Text(String(format: "%.6f", motionManager.accelYBias))
                        }
                        HStack {
                            Text("Accel Z Bias:")
                            Spacer()
                            Text(String(format: "%.6f", motionManager.accelZBias))
                        }
                        
                        // Gyro Bias
                        HStack {
                            Text("Gyro X Bias:")
                            Spacer()
                            Text(String(format: "%.6f", motionManager.gyroXBias))
                        }
                        HStack {
                            Text("Gyro Y Bias:")
                            Spacer()
                            Text(String(format: "%.6f", motionManager.gyroYBias))
                        }
                        HStack {
                            Text("Gyro Z Bias:")
                            Spacer()
                            Text(String(format: "%.6f", motionManager.gyroZBias))
                        }
                    }
                    
                    Section(header: Text("Noise Estimates")) {
                        // Accel Noise
                        HStack {
                            Text("Accel X Noise:")
                            Spacer()
                            Text(String(format: "%.6f", motionManager.accelXNoise))
                        }
                        HStack {
                            Text("Accel Y Noise:")
                            Spacer()
                            Text(String(format: "%.6f", motionManager.accelYNoise))
                        }
                        HStack {
                            Text("Accel Z Noise:")
                            Spacer()
                            Text(String(format: "%.6f", motionManager.accelZNoise))
                        }
                        
                        // Gyro Noise
                        HStack {
                            Text("Gyro X Noise:")
                            Spacer()
                            Text(String(format: "%.6f", motionManager.gyroXNoise))
                        }
                        HStack {
                            Text("Gyro Y Noise:")
                            Spacer()
                            Text(String(format: "%.6f", motionManager.gyroYNoise))
                        }
                        HStack {
                            Text("Gyro Z Noise:")
                            Spacer()
                            Text(String(format: "%.6f", motionManager.gyroZNoise))
                        }
                    }
                }
            }
            .navigationTitle("Bias & Noise Estimation")
        }
    }
}

// Part 2: Comparison of Methods
struct ComparisonView: View {
    @ObservedObject var motionManager: MotionManager
    @Binding var selectedMethod: Int
    @State private var testDuration: TimeInterval = 60 // 1 minute test
    @State private var remainingTime: Int = 60
    @State private var isRunningTest: Bool = false
    @State private var timer: Timer?
    
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Test Configuration")) {
                    Picker("Tilt Method", selection: $selectedMethod) {
                        Text("Accelerometer").tag(0)
                        Text("Gyroscope").tag(1)
                        Text("Complementary").tag(2)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .disabled(isRunningTest)
                    
                    HStack {
                        Text("Current Method:")
                        Spacer()
                        Text(methodDescription)
                            .fontWeight(.bold)
                    }
                    
                    if isRunningTest {
                        HStack {
                            Text("Time Remaining:")
                            Spacer()
                            Text("\(remainingTime) seconds")
                                .foregroundColor(.orange)
                        }
                    }
                    
                    if !isRunningTest {
                        Button("Start 1-Minute Test") {
                            startTest()
                        }
                        .disabled(!motionManager.hasBiasData || isRunningTest)
                    } else {
                        Button("Stop Test") {
                            stopTest()
                        }
                    }
                }
                
                if !motionManager.tiltData.isEmpty {
                    Section(header: Text("Tilt Measurement - \(methodDescription)")) {
                        VStack {
                            Chart {
                                ForEach(motionManager.tiltData) { dataPoint in
                                    LineMark(
                                        x: .value("Time (sec)", dataPoint.time),
                                        y: .value("Angle (°)", getRelevantTiltValue(dataPoint))
                                    )
                                    .foregroundStyle(getTiltColor())
                                }
                            }
                            .frame(height: 250)
                            .chartYScale(domain: -180...180)
                            .chartXScale(domain: 0...60)
                            .chartXAxis {
                                AxisMarks(values: .stride(by: 10))
                            }
                            .chartYAxis {
                                AxisMarks(values: .stride(by: 30))
                            }
                            
                            Text("Y-axis: Tilt Angle (degrees) | X-axis: Time (seconds)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .padding(.top, 4)
                            
                            // Current Tilt Display
                            Text("Current Tilt: \(getCurrentTiltString())")
                                .font(.title2)
                                .fontWeight(.bold)
                                .padding(.top, 8)
                        }
                    }
                    
                    Section(header: Text("Statistics")) {
                        if let stats = calculateStatistics() {
                            HStack {
                                Text("Mean:")
                                Spacer()
                                Text(String(format: "%.4f°", stats.mean))
                            }
                            
                            HStack {
                                Text("Standard Deviation:")
                                Spacer()
                                Text(String(format: "%.4f°", stats.stdDev))
                            }
                            
                            HStack {
                                Text("Min / Max:")
                                Spacer()
                                Text(String(format: "%.2f° / %.2f°", stats.min, stats.max))
                            }
                        }
                    }
                }
            }
            .navigationTitle("Tilt Method Comparison")
            .onDisappear {
                stopTest()
            }
        }
    }
    
    private var methodDescription: String {
        switch selectedMethod {
        case 0: return "Accelerometer Only"
        case 1: return "Gyroscope Only"
        case 2: return "Complementary Filter"
        default: return "Unknown"
        }
    }
    
    private func startTest() {
        guard motionManager.hasBiasData else { return }
        
        isRunningTest = true
        remainingTime = Int(testDuration)
        
        // Start the appropriate measurement based on selectedMethod
        switch selectedMethod {
        case 0:
            motionManager.runTiltTest(method: .accelerometer, duration: testDuration)
        case 1:
            motionManager.runTiltTest(method: .gyroscope, duration: testDuration)
        case 2:
            motionManager.runTiltTest(method: .complementary, duration: testDuration)
        default:
            break
        }
        
        // Start countdown timer
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            if remainingTime > 0 {
                remainingTime -= 1
            } else {
                stopTest()
            }
        }
    }
    
    private func stopTest() {
        timer?.invalidate()
        timer = nil
        isRunningTest = false
        motionManager.stopMeasurement()
    }
    
    private func getRelevantTiltValue(_ dataPoint: TiltDataPoint) -> Double {
        switch selectedMethod {
        case 0:
            return dataPoint.accelTilt
        case 1:
            return dataPoint.gyroTilt
        case 2:
            return dataPoint.filteredTilt
        default:
            return 0
        }
    }
    
    private func getTiltColor() -> Color {
        switch selectedMethod {
        case 0: return .red
        case 1: return .green
        case 2: return .blue
        default: return .gray
        }
    }
    
    private func calculateStatistics() -> (mean: Double, stdDev: Double, min: Double, max: Double)? {
        guard !motionManager.tiltData.isEmpty else { return nil }
        
        // Get the relevant tilt values based on selected method
        let values = motionManager.tiltData.map { getRelevantTiltValue($0) }
        
        // Calculate mean
        let mean = values.reduce(0, +) / Double(values.count)
        
        // Calculate standard deviation
        let sumOfSquaredDifferences = values.reduce(0) { $0 + pow($1 - mean, 2) }
        let stdDev = sqrt(sumOfSquaredDifferences / Double(values.count))
        
        // Min and max values
        let min = values.min() ?? 0
        let max = values.max() ?? 0
        
        return (mean, stdDev, min, max)
    }
    
    private func getCurrentTiltString() -> String {
        let tilt = motionManager.currentTilt
        return String(format: "%.2f°", tilt)
    }
}

// Demo: Real-time Tilt View
struct DemoView: View {
    @ObservedObject var motionManager: MotionManager
    @State private var showingChart = false
    
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Live Tilt Measurement")) {
                    HStack {
                        Text("Current Tilt:")
                        Spacer()
                        Text(motionManager.displayedTilt)
                            .fontWeight(.bold)
                            .font(.title)
                    }
                    
                    HStack {
                        Text("Device Moving:")
                        Spacer()
                        Text(motionManager.isDeviceMoving ? "Yes" : "No")
                            .foregroundColor(motionManager.isDeviceMoving ? .green : .red)
                    }
                    
                    // Graphical tilt indicator
                    VStack {
                        TiltIndicatorView(tilt: motionManager.currentTilt)
                            .frame(height: 200)
                            .padding()
                    }
                    
                    if !motionManager.isRunning {
                        Button("Start Demo") {
                            motionManager.startLiveDemo()
                        }
                        .disabled(!motionManager.hasBiasData)
                    } else {
                        Button("Stop Demo") {
                            motionManager.stopMeasurement()
                        }
                    }
                    
                    Toggle("Show Chart", isOn: $showingChart)
                }
                
                if showingChart && !motionManager.tiltData.isEmpty {
                    Section(header: Text("Tilt History")) {
                        VStack {
                            Chart {
                                ForEach(motionManager.tiltData.suffix(200)) { dataPoint in
                                    LineMark(
                                        x: .value("Time", dataPoint.time),
                                        y: .value("Tilt", dataPoint.filteredTilt)
                                    )
                                    .foregroundStyle(.blue)
                                    
                                    LineMark(
                                        x: .value("Time", dataPoint.time),
                                        y: .value("Accel", dataPoint.accelTilt)
                                    )
                                    .foregroundStyle(.red)
                                    .opacity(0.5)
                                    
                                    LineMark(
                                        x: .value("Time", dataPoint.time),
                                        y: .value("Gyro", dataPoint.gyroTilt)
                                    )
                                    .foregroundStyle(.green)
                                    .opacity(0.5)
                                }
                            }
                            .frame(height: 200)
                            .chartYScale(domain: -180...180)
                            .chartYAxis {
                                AxisMarks(values: .stride(by: 60))
                            }
                            
                            HStack {
                                Circle().fill(.blue).frame(width: 8, height: 8)
                                Text("Filtered")
                                Spacer()
                                Circle().fill(.red).frame(width: 8, height: 8)
                                Text("Accel")
                                Spacer()
                                Circle().fill(.green).frame(width: 8, height: 8)
                                Text("Gyro")
                            }
                            .font(.caption)
                            .padding(.top, 4)
                        }
                    }
                }
            }
            .navigationTitle("Tilt Demo")
        }
    }
}

struct TiltIndicatorView: View {
    let tilt: Double
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Background
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.gray.opacity(0.2))
                
                // Zero line
                Rectangle()
                    .fill(Color.gray)
                    .frame(width: geometry.size.width, height: 2)
                
                // Tilt indicator
                VStack {
                    Text(String(format: "%.1f°", tilt))
                        .fontWeight(.bold)
                        .padding(5)
                        .background(Color.black.opacity(0.7))
                        .foregroundColor(.white)
                        .cornerRadius(5)
                    
                    Rectangle()
                        .fill(Color.blue)
                        .frame(width: 5, height: 80)
                }
                .rotationEffect(Angle(degrees: tilt))
                
                // Angle markings
                ForEach([-60, -45, -30, -15, 0, 15, 30, 45, 60], id: \.self) { angle in
                    VStack {
                        Text("\(angle)°")
                            .font(.caption)
                            .foregroundColor(.gray)
                        
                        Rectangle()
                            .fill(angle == 0 ? Color.black : Color.gray)
                            .frame(width: angle == 0 ? 2 : 1, height: angle == 0 ? 15 : 10)
                    }
                    .offset(y: -geometry.size.height * 0.35)
                    .rotationEffect(Angle(degrees: Double(angle)))
                }
            }
        }
    }
}

#if os(iOS)
class MotionManager: ObservableObject {
    private let motion = CMMotionManager()
    private var timer: Timer?
    
    private let updateInterval = 0.01
    private var alpha: Double = 0.98  // Now dynamic based on noise
    
    // Motion detection threshold (multiplier of noise level)
    private let thresholdMultiplier: Double = 4.0 // Increased for better noise rejection
    private var motionThreshold: Double = 0.0
    
    // Additional noise filters
    private let accelLowPassFilter = LowPassFilter(filterFactor: 0.1)
    private let gyroLowPassFilter = LowPassFilter(filterFactor: 0.1)
    
    // Runtime state
    @Published var isRunning: Bool = false
    @Published var isDeviceMoving: Bool = false
    private var isMoving: Bool = false
    @Published var isRunningPart2: Bool = false
    private var runningMode: RunningMode = .none
    private var logCounter: Int = 0
    private var gyroIntegratedTilt: Double = 0.0
    
    // Tilt history for charts
    private var tiltHistory: [(time: Double, tilt: Double)] = []
    @Published var currentTilt: Double = 0.0
    @Published var displayedTilt: String = "0.00°"
    
    // Calibration tracking
    @Published var isBiasEstimationRunning: Bool = false
    @Published var estimationMessageString: String = "Not started"
    
    // Raw sensor readings
    private var rawAccelX: Double = 0.0
    private var rawAccelY: Double = 0.0
    private var rawAccelZ: Double = 0.0
    private var rawGyroX: Double = 0.0
    private var rawGyroY: Double = 0.0
    private var rawGyroZ: Double = 0.0
    
    // Additional properties for better zeroing
    private var initialTiltVector: (x: Double, y: Double, z: Double) = (0, 0, 1)
    private var initialAccelTilt: Double = 0.0
    private var initialAccelTiltOffset: Double = 0.0  // Keep for compatibility
    
    // Bias values
    @Published var accelXBias: Double = 0.0
    @Published var accelYBias: Double = 0.0
    @Published var accelZBias: Double = 0.0
    @Published var gyroXBias: Double = 0.0
    @Published var gyroYBias: Double = 0.0
    @Published var gyroZBias: Double = 0.0
    
    // Noise values
    @Published var accelXNoise: Double = 0.0  
    @Published var accelYNoise: Double = 0.0  
    @Published var accelZNoise: Double = 0.0  
    @Published var gyroXNoise: Double = 0.0
    @Published var gyroYNoise: Double = 0.0
    @Published var gyroZNoise: Double = 0.0
    
    // Signal-to-noise ratios for confidence weighting
    private var accelSNR: Double = 0.0  
    private var gyroSNR: Double = 0.0
    
    // Current corrected values
    @Published var correctedAccelX: Double = 0.0  
    @Published var correctedAccelY: Double = 0.0  
    @Published var correctedAccelZ: Double = 0.0  
    @Published var correctedGyroX: Double = 0.0
    @Published var correctedGyroY: Double = 0.0
    @Published var correctedGyroZ: Double = 0.0
    
    // Calibration state
    @Published var isCalibrated: Bool = false
    
    // Private background queue for operations
    private let operationQueue = OperationQueue()
    
    // Drift compensation
    private var gyroDriftOffset: Double = 0.0
    private var gyroDriftRate: Double = 0.0
    private var lastGyroIntegratedTilt: Double = 0.0
    private var driftSamples: [(time: TimeInterval, drift: Double)] = []
    private var lastDriftUpdateTime: Date = Date()
    
    enum RunningMode {
        case none
        case biasEstimation
        case tiltTracking
        case liveDemo
    }
    
    // Public formatted strings for UI display
    var accelBiasString: String {
        return String(format: "x: %.5f, y: %.5f, z: %.5f", accelXBias, accelYBias, accelZBias)
    }
    
    var accelNoiseString: String {
        return String(format: "x: %.5f, y: %.5f, z: %.5f", accelXNoise, accelYNoise, accelZNoise)
    }
    
    var gyroBiasString: String {
        return String(format: "x: %.5f, y: %.5f, z: %.5f", gyroXBias, gyroYBias, gyroZBias)
    }
    
    var gyroNoiseString: String {
        return String(format: "x: %.5f, y: %.5f, z: %.5f", gyroXNoise, gyroYNoise, gyroZNoise)
    }
    
    var correctedAccelString: String {
        return String(format: "x: %.3f, y: %.3f, z: %.3f", correctedAccelX, correctedAccelY, correctedAccelZ)
    }
    
    var correctedGyroString: String {
        return String(format: "x: %.3f, y: %.3f, z: %.3f", correctedGyroX, correctedGyroY, correctedGyroZ)
    }
    
    var accelSNRString: String {
        return String(format: "%.2f", accelSNR)
    }
    
    var gyroSNRString: String {
        return String(format: "%.2f", gyroSNR)
    }
    
    var motionThresholdString: String {
        return String(format: "%.5f", motionThreshold)
    }
    
    var alphaString: String {
        return String(format: "%.4f", alpha)
    }
    
    @Published var hasBiasData: Bool = false
    @Published var filteredTilt: Double = 0.0
    @Published var tiltData: [TiltDataPoint] = []
    
    private var time: Double = 0.0
    private var gyroTilt: Double = 0.0
    
    // Tilt averaging variables
    private var tiltSamples: [Double] = []
    private var sampleTimer: Double = 0.0
    private let samplePeriod: Double = 0.1 // 0.1 second sampling period
    private var secondTimer: Double = 0.0
    
    // Calculate standard deviation helper function
    private func standardDeviation(values: [Double]) -> Double {
        let mean = values.reduce(0, +) / Double(values.count)
        let variance = values.map { pow($0 - mean, 2) }.reduce(0, +) / Double(values.count)
        return sqrt(variance)
    }
    
    func stopMeasurement() {
        clear()
        print("Measurement stopped")
        DispatchQueue.main.async {
            self.isRunning = false
            self.isRunningPart2 = false
            self.isDeviceMoving = false
        }
    }
    
    init() {
        // Ensure the motion manager is available
        if !motion.isAccelerometerAvailable || !motion.isGyroAvailable {
            print("Warning: Accelerometer or gyroscope not available on this device")
        }
    }
    
    deinit {
        clear()
    }

    func clear() {
        DispatchQueue.main.async {
            self.tiltData.removeAll()
            self.time = 0.0
            self.filteredTilt = 0.0
            self.gyroTilt = 0.0
            self.gyroIntegratedTilt = 0.0  // Ensure gyro integration is reset
            self.correctedAccelX = 0.0
            self.correctedAccelY = 0.0
            self.correctedAccelZ = 0.0
            self.correctedGyroX = 0.0
            self.correctedGyroY = 0.0
            self.correctedGyroZ = 0.0
            self.isCalibrated = false
            self.isMoving = false
            self.isRunningPart2 = false
            self.initialAccelTilt = 0.0
            self.initialAccelTiltOffset = 0.0
            self.initialTiltVector = (0, 0, 1)  // Reset to default gravity vector
            self.tiltSamples.removeAll()
            self.sampleTimer = 0.0
            self.secondTimer = 0.0
            self.currentTilt = 0.0
            self.displayedTilt = "0.00°"
            
            // Reset drift compensation
            self.gyroDriftOffset = 0.0
            self.gyroDriftRate = 0.0
            self.lastGyroIntegratedTilt = 0.0
            self.driftSamples.removeAll()
            self.lastDriftUpdateTime = Date()
        }
        
        self.timer?.invalidate()
        self.timer = nil
        
        if motion.isAccelerometerActive {
            motion.stopAccelerometerUpdates()
        }
        
        if motion.isGyroActive {
            motion.stopGyroUpdates()
        }
        
        // Reset the low-pass filters
        accelLowPassFilter.reset()
        gyroLowPassFilter.reset()
    }
    
    // Calculate SNR and adjust alpha for complementary filter
    private func calculateSNRAndAlpha() {
        // Calculate Signal-to-Noise ratio
        let accelNoise = (accelXNoise + accelYNoise + accelZNoise) / 3.0
        let gyroNoise = (gyroXNoise + gyroYNoise + gyroZNoise) / 3.0
        
        // For accelerometer, signal is roughly 1g (9.8 m/s²)
        let accelSignal = 1.0
        
        // For gyro, assume a typical signal based on device movement
        let gyroSignal = 1.0
        
        // Calculate SNR = signal/noise
        accelSNR = accelSignal / (accelNoise > 0 ? accelNoise : 0.001)
        gyroSNR = gyroSignal / (gyroNoise > 0 ? gyroNoise : 0.001)
        
        // Set alpha based on SNR ratio - gives more weight to sensor with better SNR
        // For IMU fusion, we want a balance between gyro and accel
        let totalSNR = accelSNR + gyroSNR
        if totalSNR > 0 {
            // Scale alpha between 0.7 and 0.95 based on relative SNR
            alpha = 0.7 + (0.25 * gyroSNR / totalSNR)
        } else {
            // Default value if SNR calculation fails
            alpha = 0.85
        }
        
        // Set motion detection threshold based on combined noise levels
        motionThreshold = max(gyroNoise, accelNoise) * thresholdMultiplier
        
        print("SNR - Accel: \(accelSNR), Gyro: \(gyroSNR)")
        print("Alpha (IMU fusion): \(alpha)")
        print("Motion Detection Threshold: \(motionThreshold)")
        
        DispatchQueue.main.async {
            self.isCalibrated = true
        }
    }
    
    // Detect if the device is moving beyond noise level
    private func detectMotion(accelX: Double, accelY: Double, accelZ: Double, 
                             gyroX: Double, gyroY: Double, gyroZ: Double,
                             thresholdMultiplier: Double? = nil) -> Bool {
        // Check both accelerometer and gyroscope for motion
        let accelMagnitude = sqrt(pow(accelX, 2) + pow(accelY, 2) + pow(accelZ - 1.0, 2))
        let gyroMagnitude = sqrt(pow(gyroX, 2) + pow(gyroY, 2) + pow(gyroZ, 2))
        
        // Calculate noise thresholds
        let accelNoiseLevel = sqrt(
            pow(self.accelXNoise, 2) +
            pow(self.accelYNoise, 2) +
            pow(self.accelZNoise, 2)
        )
        
        let gyroNoiseLevel = sqrt(
            pow(self.gyroXNoise, 2) +
            pow(self.gyroYNoise, 2) +
            pow(self.gyroZNoise, 2)
        )
        
        // Use custom threshold multiplier if provided, otherwise use the default
        let multiplier = thresholdMultiplier ?? self.thresholdMultiplier
        
        let accelThreshold = accelNoiseLevel * multiplier
        let gyroThreshold = gyroNoiseLevel * multiplier
        
        // Return true if either sensor detects motion
        return gyroMagnitude > gyroThreshold || accelMagnitude > accelThreshold
    }

    // ------------------------
    // Part 1: Bias + Noise Estimation
    // ------------------------
    func estimateBiasAndNoise(sampleCount: Int = 500) {
        clear()
        runningMode = .biasEstimation
        isRunning = true
        hasBiasData = false
        
        DispatchQueue.main.async {
            self.estimationMessageString = "Starting bias/noise estimation (\(sampleCount) samples)"
        }
        
        // Reset values
        self.accelXBias = 0.0
        self.accelYBias = 0.0
        self.accelZBias = 0.0
        self.gyroXBias = 0.0
        self.gyroYBias = 0.0
        self.gyroZBias = 0.0
        
        self.accelXNoise = 0.0
        self.accelYNoise = 0.0
        self.accelZNoise = 0.0
        self.gyroXNoise = 0.0
        self.gyroYNoise = 0.0
        self.gyroZNoise = 0.0
        
        var samples = 0
        var accelXValues: [Double] = []
        var accelYValues: [Double] = []
        var accelZValues: [Double] = []
        var gyroXValues: [Double] = []
        var gyroYValues: [Double] = []
        var gyroZValues: [Double] = []
        
        self.isBiasEstimationRunning = true
        
        // Run in queue
        self.operationQueue.addOperation { [weak self] in
            guard let self = self else { return }
            
            let motion = CMMotionManager()
            motion.accelerometerUpdateInterval = 0.01
            motion.gyroUpdateInterval = 0.01
            
            motion.startAccelerometerUpdates(to: .main) { (accelerometerData, error) in
                guard let accelerometerData = accelerometerData, error == nil else { return }
                
                self.rawAccelX = accelerometerData.acceleration.x
                self.rawAccelY = accelerometerData.acceleration.y
                self.rawAccelZ = accelerometerData.acceleration.z
                
                if self.isBiasEstimationRunning {
                    accelXValues.append(accelerometerData.acceleration.x)
                    accelYValues.append(accelerometerData.acceleration.y)
                    accelZValues.append(accelerometerData.acceleration.z)
                    
                    DispatchQueue.main.async {
                        self.estimationMessageString = "Collecting samples: \(samples)/\(sampleCount)"
                    }
                    
                    if samples >= sampleCount {
                        self.isBiasEstimationRunning = false
                    }
                }
            }
            
            motion.startGyroUpdates(to: .main) { (gyroData, error) in
                guard let gyroData = gyroData, error == nil else { return }
                
                self.rawGyroX = gyroData.rotationRate.x
                self.rawGyroY = gyroData.rotationRate.y
                self.rawGyroZ = gyroData.rotationRate.z
                
                if self.isBiasEstimationRunning {
                    gyroXValues.append(gyroData.rotationRate.x)
                    gyroYValues.append(gyroData.rotationRate.y)
                    gyroZValues.append(gyroData.rotationRate.z)
                    
                    samples += 1
                    
                    if samples >= sampleCount {
                        motion.stopAccelerometerUpdates()
                        motion.stopGyroUpdates()
                        
                        // Calculate bias (average/mean)
                        self.accelXBias = accelXValues.reduce(0.0, +) / Double(accelXValues.count)
                        self.accelYBias = accelYValues.reduce(0.0, +) / Double(accelYValues.count)
                        self.accelZBias = accelZValues.reduce(0.0, +) / Double(accelZValues.count)
                        self.gyroXBias = gyroXValues.reduce(0.0, +) / Double(gyroXValues.count)
                        self.gyroYBias = gyroYValues.reduce(0.0, +) / Double(gyroYValues.count)
                        self.gyroZBias = gyroZValues.reduce(0.0, +) / Double(gyroZValues.count)
                        
                        // Calculate noise (standard deviation)
                        self.accelXNoise = self.standardDeviation(values: accelXValues)
                        self.accelYNoise = self.standardDeviation(values: accelYValues)
                        self.accelZNoise = self.standardDeviation(values: accelZValues)
                        self.gyroXNoise = self.standardDeviation(values: gyroXValues)
                        self.gyroYNoise = self.standardDeviation(values: gyroYValues)
                        self.gyroZNoise = self.standardDeviation(values: gyroZValues)
                        
                        // Capture initial tilt vector
                        self.initialTiltVector = (x: self.accelXBias, y: self.accelYBias, z: self.accelZBias)
                        self.initialAccelTilt = self.calculateTiltAngle(accelX: self.accelXBias, accelZ: self.accelZBias)
                        self.initialAccelTiltOffset = abs(atan2(self.accelXBias, self.accelZBias) * 180 / .pi)
                        
                        // Set calibration values
                        DispatchQueue.main.async {
                            self.isCalibrated = true
                            self.hasBiasData = true
                            self.isRunning = false
                            self.estimationMessageString = "Calibration Complete: Accel-Only Tilt Measurement"
                        }
                    }
                }
            }
        }
    }

    // ------------------------
    // Part 2: Tilt Tracking
    // ------------------------
    func runTiltTracking() {
        guard hasBiasData else {
            print("Error: Cannot run tilt tracking without bias data. Run estimateBiasAndNoise first.")
            return
        }
        
        clear()
        runningMode = .tiltTracking
        isRunning = true
        isRunningPart2 = true
        
        // Explicitly reset gyro tilt to ensure it starts at zero
        gyroIntegratedTilt = 0.0
        currentTilt = 0.0
        
        let startTime = Date()
        var currentTilt = 0.0
        
        // Position reference is critical for zeroing
        let initialAccelTilt = atan2(accelXBias, accelZBias) * 180 / .pi
        print("Initial accel tilt (will be zeroed): \(initialAccelTilt)°")
        
        // Configure motion manager
        motion.accelerometerUpdateInterval = updateInterval
        motion.gyroUpdateInterval = updateInterval
        motion.startAccelerometerUpdates()
        motion.startGyroUpdates()
        
        timer = Timer.scheduledTimer(withTimeInterval: updateInterval, repeats: true) { [weak self] _ in
            guard let self = self,
                  let accel = self.motion.accelerometerData?.acceleration,
                  let gyro = self.motion.gyroData?.rotationRate else { return }
            
            // Store raw data
            let rawAccelX = accel.x
            let rawAccelY = accel.y
            let rawAccelZ = accel.z
            let rawGyroX = gyro.x
            let rawGyroY = gyro.y
            let rawGyroZ = gyro.z
            
            // Apply bias correction
            let correctedAccelX = rawAccelX - self.accelXBias
            let correctedAccelY = rawAccelY - self.accelYBias
            let correctedAccelZ = rawAccelZ - self.accelZBias
            
            let correctedGyroX = rawGyroX - self.gyroXBias
            let correctedGyroY = rawGyroY - self.gyroYBias
            let correctedGyroZ = rawGyroZ - self.gyroZBias
            
            // Calculate tilt from accelerometer (in degrees)
            let instantAccelTilt = atan2(rawAccelX, rawAccelZ) * 180 / .pi
            
            // Apply zeroing by subtracting initial tilt angle 
            let zeroedAccelTilt = instantAccelTilt - initialAccelTilt
            
            // Integrate gyro for display only - not used in final calculation
            self.gyroIntegratedTilt += correctedGyroY * self.updateInterval * (180 / .pi)
            
            // Check if device is moving based on noise thresholds
            let accelMagnitude = sqrt(
                pow(correctedAccelX, 2) +
                pow(correctedAccelY, 2) +
                pow(correctedAccelZ, 2)
            )
            
            let gyroMagnitude = sqrt(
                pow(correctedGyroX, 2) +
                pow(correctedGyroY, 2) +
                pow(correctedGyroZ, 2)
            )
            
            // Calculate total noise levels
            let accelNoiseLevel = sqrt(
                pow(self.accelXNoise, 2) +
                pow(self.accelYNoise, 2) +
                pow(self.accelZNoise, 2)
            )
            
            let gyroNoiseLevel = sqrt(
                pow(self.gyroXNoise, 2) +
                pow(self.gyroYNoise, 2) +
                pow(self.gyroZNoise, 2)
            )
            
            // Using 4.0 multiplier for better noise rejection
            let thresholdMultiplier = 4.0
            let accelThreshold = accelNoiseLevel * thresholdMultiplier
            let gyroThreshold = gyroNoiseLevel * thresholdMultiplier
            
            // Determine if the device is moving
            let isMoving = accelMagnitude > accelThreshold || gyroMagnitude > gyroThreshold
            
            // For accel-only tilt calculation, use alpha of 0.1
            // This gives much more weight to accelerometer data (90%)
            let alpha = 0.1
            
            // Apply complementary filter
            if isMoving {
                // When moving, use the complementary filter with heavy bias toward accelerometer
                currentTilt = alpha * self.gyroIntegratedTilt + (1.0 - alpha) * zeroedAccelTilt
            } else {
                // When stationary, hold at 0
                currentTilt = 0.0
            }
            
            // Update tilt data for display
            let timeElapsed = Date().timeIntervalSince(startTime)
            self.tiltHistory.append((time: timeElapsed, tilt: currentTilt))
            
            // Update UI properties
            DispatchQueue.main.async {
                self.currentTilt = currentTilt
                self.displayedTilt = String(format: "%.2f°", currentTilt)
                self.isDeviceMoving = isMoving
                
                // Add to chart data
                self.tiltData.append(TiltDataPoint(
                    time: timeElapsed,
                    accelTilt: zeroedAccelTilt,
                    gyroTilt: self.gyroIntegratedTilt,
                    filteredTilt: currentTilt
                ))
                
                // Limit data points to avoid performance issues
                if self.tiltData.count > 1000 {
                    self.tiltData.removeFirst(100)
                }
            }
            
            // Log data once per second for debugging
            self.logCounter += 1
            if self.logCounter >= Int(1.0/self.updateInterval) {
                self.logCounter = 0
                print("Time: \(String(format: "%.2f", timeElapsed))s, " +
                      "Tilt: \(String(format: "%.2f", currentTilt))°, " +
                      "Raw Accel Tilt: \(String(format: "%.2f", instantAccelTilt))°, " +
                      "Zeroed Accel Tilt: \(String(format: "%.2f", zeroedAccelTilt))°, " +
                      "Moving: \(isMoving)")
            }
        }
    }

    // ------------------------
    // Demo Mode: Real-time Tilt Visualization
    // ------------------------
    func startLiveDemo() {
        guard hasBiasData else {
            print("Error: Cannot run tilt demo without bias data. Run estimateBiasAndNoise first.")
            return
        }
        
        clear()
        runningMode = .liveDemo
        isRunning = true
        
        // Explicitly reset gyro tilt to ensure it starts at zero
        gyroIntegratedTilt = 0.0
        currentTilt = 0.0
        
        // Keep track of time spent at rest for more aggressive drift correction
        var timeAtRest: TimeInterval = 0.0
        var continuousDriftCorrectionApplied: Bool = false
        
        let startTime = Date()
        
        // Position reference is critical for zeroing
        let initialAccelTilt = atan2(accelXBias, accelZBias) * 180 / .pi
        print("Initial accel tilt (will be zeroed): \(initialAccelTilt)°")
        
        // Configure motion manager
        motion.accelerometerUpdateInterval = updateInterval
        motion.gyroUpdateInterval = updateInterval
        motion.startAccelerometerUpdates()
        motion.startGyroUpdates()
        
        timer = Timer.scheduledTimer(withTimeInterval: updateInterval, repeats: true) { [weak self] _ in
            guard let self = self,
                  let accel = self.motion.accelerometerData?.acceleration,
                  let gyro = self.motion.gyroData?.rotationRate else { return }
            
            // Store raw data
            let rawAccelX = accel.x
            let rawAccelY = accel.y
            let rawAccelZ = accel.z
            let rawGyroX = gyro.x
            let rawGyroY = gyro.y
            let rawGyroZ = gyro.z
            
            // Apply bias correction
            let correctedAccelX = rawAccelX - self.accelXBias
            let correctedAccelY = rawAccelY - self.accelYBias
            let correctedAccelZ = rawAccelZ - self.accelZBias
            
            let correctedGyroX = rawGyroX - self.gyroXBias
            let correctedGyroY = rawGyroY - self.gyroYBias
            let correctedGyroZ = rawGyroZ - self.gyroZBias
            
            // Calculate accelerometer tilt (in degrees)
            let instantAccelTilt = atan2(rawAccelX, rawAccelZ) * 180 / .pi
            
            // Apply zeroing by subtracting initial tilt angle 
            let zeroedAccelTilt = instantAccelTilt - initialAccelTilt
            
            // Use a slightly lower threshold for demo mode
            let restThresholdMultiplier = 3.5 // Lower than the default 4.0
            
            // Check if device is at rest with a more sensitive threshold
            let isAtRest = !self.detectMotion(
                accelX: correctedAccelX, 
                accelY: correctedAccelY, 
                accelZ: correctedAccelZ,
                gyroX: correctedGyroX, 
                gyroY: correctedGyroY, 
                gyroZ: correctedGyroZ,
                thresholdMultiplier: restThresholdMultiplier
            )
            
            // Update time at rest counter
            if isAtRest {
                timeAtRest += self.updateInterval
            } else {
                timeAtRest = 0.0
                self.lastDriftUpdateTime = Date() // Reset drift calculation when moving
            }
            
            // Calculate drift correction when at rest
            if isAtRest && timeAtRest > 0.5 { // Need at least 0.5s of rest to calculate drift
                let currentTime = Date()
                let timeSinceLastUpdate = currentTime.timeIntervalSince(self.lastDriftUpdateTime)
                
                if timeSinceLastUpdate > 0 {
                    // Calculate how much the gyro has drifted since last update
                    let driftAmount = self.gyroIntegratedTilt - self.lastGyroIntegratedTilt
                    
                    // Only record if there's any drift (avoid dividing by zero)
                    if abs(driftAmount) > 0.001 {
                        // Calculate drift rate in degrees per second
                        let instantDriftRate = driftAmount / timeSinceLastUpdate
                        
                        // Add to drift samples
                        self.driftSamples.append((time: timeAtRest, drift: instantDriftRate))
                        
                        // Keep the last 10 samples for a running average
                        if self.driftSamples.count > 10 {
                            self.driftSamples.removeFirst()
                        }
                        
                        // Calculate average drift rate from samples
                        if self.driftSamples.count > 2 {
                            let totalDrift = self.driftSamples.reduce(0) { $0 + $1.drift }
                            self.gyroDriftRate = totalDrift / Double(self.driftSamples.count)
                            
                            // If we've been at rest for a while, apply the continuous drift correction
                            if timeAtRest > 1.0 {
                                continuousDriftCorrectionApplied = true
                            }
                        }
                    }
                    
                    // Update for next calculation
                    self.lastGyroIntegratedTilt = self.gyroIntegratedTilt
                    self.lastDriftUpdateTime = currentTime
                }
            }
            
            // Apply gyro drift correction
            var correctedGyroYWithDrift: Double = 0.0
            
            if isAtRest {
                // When device is very still, use zero
                correctedGyroYWithDrift = 0.0
                
                // For demo mode, use time-based drift correction
                let driftCorrectionFactor = timeAtRest > 1.0 ? 0.95 : 0.98
                self.gyroIntegratedTilt *= driftCorrectionFactor
                
                // If at rest for more than 2 seconds, pull strongly toward zero
                if timeAtRest > 2.0 {
                    self.gyroIntegratedTilt *= 0.9
                }
                
                // After 3 seconds of no movement, just reset to zero
                if timeAtRest > 3.0 {
                    self.gyroIntegratedTilt = 0.0
                    self.gyroDriftOffset = 0.0 // Reset offset when we reset tilt
                }
            } else {
                // When moving, apply drift compensation to raw gyro reading
                if continuousDriftCorrectionApplied {
                    // Subtract the drift rate to compensate
                    correctedGyroYWithDrift = correctedGyroY - (self.gyroDriftRate * self.updateInterval)
                } else {
                    correctedGyroYWithDrift = correctedGyroY
                }
                
                // Integrate gyro 
                let gyroIncrement = correctedGyroYWithDrift * self.updateInterval * (180 / .pi)
                self.gyroIntegratedTilt += gyroIncrement
            }
            
            // Apply low-pass filtering to both sensors
            let filteredAccelTilt = self.accelLowPassFilter.apply(value: zeroedAccelTilt, axis: 0)
            let filteredGyroTilt = self.gyroLowPassFilter.apply(value: self.gyroIntegratedTilt, axis: 0)
            
            // Use complementary filter with dynamic alpha
            // When still, favor accelerometer more (alpha closer to 0.2)
            // When moving, favor gyro more (alpha closer to 0.98)
            let dynamicAlpha = isAtRest ? 0.2 : 0.98
            let filteredTilt = dynamicAlpha * filteredGyroTilt + (1.0 - dynamicAlpha) * filteredAccelTilt
            
            // Update tilt data for display
            let timeElapsed = Date().timeIntervalSince(startTime)
            
            // Update UI properties
            DispatchQueue.main.async {
                self.currentTilt = filteredTilt
                self.displayedTilt = String(format: "%.2f°", filteredTilt)
                self.isDeviceMoving = !isAtRest
                
                // Add to chart data
                self.tiltData.append(TiltDataPoint(
                    time: timeElapsed,
                    accelTilt: zeroedAccelTilt,
                    gyroTilt: self.gyroIntegratedTilt,
                    filteredTilt: filteredTilt
                ))
                
                // Limit data points to avoid performance issues
                if self.tiltData.count > 1000 {
                    self.tiltData.removeFirst(100)
                }
            }
            
            // Log data periodically for debugging
            self.logCounter += 1
            if self.logCounter >= Int(1.0/self.updateInterval) {
                self.logCounter = 0
                print("Time: \(String(format: "%.2f", timeElapsed))s, " +
                      "Tilt: \(String(format: "%.2f", filteredTilt))°, " +
                      "Accel: \(String(format: "%.2f", zeroedAccelTilt))°, " +
                      "Gyro: \(String(format: "%.2f", self.gyroIntegratedTilt))°, " +
                      "At Rest: \(isAtRest), " +
                      "Rest Time: \(String(format: "%.1f", timeAtRest))s, " +
                      "Drift Rate: \(String(format: "%.6f", self.gyroDriftRate))°/s")
            }
        }
    }

    // Helper function to calculate tilt angle from accelerometer
    private func calculateTiltAngle(accelX: Double, accelZ: Double) -> Double {
        return atan2(accelX, accelZ) * 180 / .pi
    }

    // Enum to track the tilt measurement method
    enum TiltMeasurementMethod {
        case accelerometer
        case gyroscope
        case complementary
    }
    
    // Run a tilt test with the specified method for a fixed duration
    func runTiltTest(method: TiltMeasurementMethod, duration: TimeInterval = 60.0) {
        guard hasBiasData else {
            print("Error: Cannot run tilt test without bias data. Run estimateBiasAndNoise first.")
            return
        }
        
        clear()
        runningMode = .tiltTracking
        isRunning = true
        
        // Explicitly reset gyro integration to zero
        gyroIntegratedTilt = 0.0
        currentTilt = 0.0
        
        // Keep track of time spent at rest for more aggressive drift correction
        var timeAtRest: TimeInterval = 0.0
        var continuousDriftCorrectionApplied: Bool = false
        
        let startTime = Date()
        
        // Position reference is critical for zeroing
        let initialAccelTilt = atan2(accelXBias, accelZBias) * 180 / .pi
        print("Initial accel tilt (will be zeroed): \(initialAccelTilt)°")
        
        // Configure motion manager
        motion.accelerometerUpdateInterval = updateInterval
        motion.gyroUpdateInterval = updateInterval
        motion.startAccelerometerUpdates()
        motion.startGyroUpdates()
        
        // Set up auto-stop timer for the test duration
        DispatchQueue.main.asyncAfter(deadline: .now() + duration) { [weak self] in
            guard let self = self, self.isRunning else { return }
            print("Test completed after \(duration) seconds")
            self.stopMeasurement()
        }
        
        timer = Timer.scheduledTimer(withTimeInterval: updateInterval, repeats: true) { [weak self] _ in
            guard let self = self,
                  let accel = self.motion.accelerometerData?.acceleration,
                  let gyro = self.motion.gyroData?.rotationRate else { return }
            
            // Store raw data
            let rawAccelX = accel.x
            let rawAccelY = accel.y
            let rawAccelZ = accel.z
            let rawGyroX = gyro.x
            let rawGyroY = gyro.y
            let rawGyroZ = gyro.z
            
            // Apply bias correction
            let correctedAccelX = rawAccelX - self.accelXBias
            let correctedAccelY = rawAccelY - self.accelYBias
            let correctedAccelZ = rawAccelZ - self.accelZBias
            
            let correctedGyroX = rawGyroX - self.gyroXBias
            let correctedGyroY = rawGyroY - self.gyroYBias
            let correctedGyroZ = rawGyroZ - self.gyroZBias
            
            // Calculate accelerometer tilt (in degrees)
            let instantAccelTilt = atan2(rawAccelX, rawAccelZ) * 180 / .pi
            
            // Apply zeroing by subtracting initial tilt angle 
            let zeroedAccelTilt = instantAccelTilt - initialAccelTilt
            
            // Use a lower threshold for detecting rest in test mode
            // This makes the app more sensitive to small movements
            let restThresholdMultiplier = 3.0 // Lower than the default 4.0
            
            // Check if device is at rest with a more sensitive threshold
            let isAtRest = !self.detectMotion(
                accelX: correctedAccelX, 
                accelY: correctedAccelY, 
                accelZ: correctedAccelZ,
                gyroX: correctedGyroX, 
                gyroY: correctedGyroY, 
                gyroZ: correctedGyroZ,
                thresholdMultiplier: restThresholdMultiplier
            )
            
            // Update time at rest counter
            if isAtRest {
                timeAtRest += self.updateInterval
            } else {
                timeAtRest = 0.0
                self.lastDriftUpdateTime = Date() // Reset drift calculation when moving
            }
            
            // Calculate drift correction when at rest
            if isAtRest && timeAtRest > 0.5 { // Need at least 0.5s of rest to calculate drift
                let currentTime = Date()
                let timeSinceLastUpdate = currentTime.timeIntervalSince(self.lastDriftUpdateTime)
                
                if timeSinceLastUpdate > 0 {
                    // Calculate how much the gyro has drifted since last update
                    let driftAmount = self.gyroIntegratedTilt - self.lastGyroIntegratedTilt
                    
                    // Only record if there's any drift (avoid dividing by zero)
                    if abs(driftAmount) > 0.001 {
                        // Calculate drift rate in degrees per second
                        let instantDriftRate = driftAmount / timeSinceLastUpdate
                        
                        // Add to drift samples
                        self.driftSamples.append((time: timeAtRest, drift: instantDriftRate))
                        
                        // Keep the last 10 samples for a running average
                        if self.driftSamples.count > 10 {
                            self.driftSamples.removeFirst()
                        }
                        
                        // Calculate average drift rate from samples
                        if self.driftSamples.count > 2 {
                            let totalDrift = self.driftSamples.reduce(0) { $0 + $1.drift }
                            self.gyroDriftRate = totalDrift / Double(self.driftSamples.count)
                            
                            // If we've been at rest for a while, apply the continuous drift correction
                            if timeAtRest > 1.0 {
                                continuousDriftCorrectionApplied = true
                            }
                        }
                    }
                    
                    // Update for next calculation
                    self.lastGyroIntegratedTilt = self.gyroIntegratedTilt
                    self.lastDriftUpdateTime = currentTime
                }
            }
            
            // Apply gyro drift correction
            var correctedGyroYWithDrift: Double = 0.0
            
            if isAtRest {
                // When device is very still, use zero
                correctedGyroYWithDrift = 0.0
                
                // For gyroscope-only method, apply special handling
                if method == .gyroscope {
                    // Gradually pull back to zero when at rest
                    let driftCorrectionFactor = timeAtRest > 1.0 ? 0.95 : 0.98
                    self.gyroIntegratedTilt *= driftCorrectionFactor
                    
                    // If at rest for more than 2 seconds, pull strongly toward zero
                    if timeAtRest > 2.0 {
                        self.gyroIntegratedTilt *= 0.9
                    }
                    
                    // After 3 seconds of no movement, just reset to zero
                    if timeAtRest > 3.0 {
                        self.gyroIntegratedTilt = 0.0
                        self.gyroDriftOffset = 0.0 // Reset offset when we reset tilt
                    }
                }
            } else {
                // When moving, apply drift compensation to raw gyro reading
                if continuousDriftCorrectionApplied {
                    // Subtract the drift rate to compensate
                    correctedGyroYWithDrift = correctedGyroY - (self.gyroDriftRate * self.updateInterval)
                } else {
                    correctedGyroYWithDrift = correctedGyroY
                }
                
                // Integrate gyro 
                let gyroIncrement = correctedGyroYWithDrift * self.updateInterval * (180 / .pi)
                self.gyroIntegratedTilt += gyroIncrement
            }
            
            // Determine filtered tilt based on test method
            var filteredTilt: Double = 0.0
            
            switch method {
            case .accelerometer:
                // Use accelerometer only
                filteredTilt = zeroedAccelTilt
                
            case .gyroscope:
                // Use gyroscope only (with drift correction)
                filteredTilt = self.gyroIntegratedTilt
                
            case .complementary:
                // Use complementary filter with dynamic alpha
                // When at rest, heavily favor accelerometer to correct drift
                let alpha = isAtRest ? 0.2 : 0.98
                filteredTilt = alpha * self.gyroIntegratedTilt + (1.0 - alpha) * zeroedAccelTilt
            }
            
            // Update tilt data for display
            let timeElapsed = Date().timeIntervalSince(startTime)
            
            // Update UI properties
            DispatchQueue.main.async {
                self.currentTilt = filteredTilt
                self.displayedTilt = String(format: "%.2f°", filteredTilt)
                self.isDeviceMoving = !isAtRest
                
                // Add to chart data
                self.tiltData.append(TiltDataPoint(
                    time: timeElapsed,
                    accelTilt: zeroedAccelTilt,
                    gyroTilt: self.gyroIntegratedTilt,
                    filteredTilt: filteredTilt
                ))
            }
            
            // Log data once per second for debugging
            self.logCounter += 1
            if self.logCounter >= Int(1.0/self.updateInterval) {
                self.logCounter = 0
                print("Time: \(String(format: "%.2f", timeElapsed))s, " +
                      "Method: \(method), " +
                      "Tilt: \(String(format: "%.2f", filteredTilt))°, " +
                      "At Rest: \(isAtRest), " +
                      "Rest Time: \(String(format: "%.1f", timeAtRest))s, " +
                      "Drift Rate: \(String(format: "%.6f", self.gyroDriftRate))°/s")
            }
        }
    }
}

// Low-pass filter to reduce noise
class LowPassFilter {
    private var filterFactor: Double
    private var lastValues: [Double] = [0, 0, 0] // x, y, z
    
    init(filterFactor: Double) {
        self.filterFactor = filterFactor
    }
    
    func apply(value: Double, axis: Int) -> Double {
        if axis >= 0 && axis < lastValues.count {
            lastValues[axis] = lastValues[axis] * (1.0 - filterFactor) + value * filterFactor
            return lastValues[axis]
        }
        return value
    }
    
    func reset() {
        lastValues = [0, 0, 0]
    }
}
#endif

#Preview {
    ContentView()
}
