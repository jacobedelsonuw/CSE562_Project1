//
//  AgenticAiAPP_App.swift
//  AgenticAiAPP_
//
//  Created by Jacob Edelson on 4/7/25.
//

import SwiftUI

@main
struct AgenticAiAPP_App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
