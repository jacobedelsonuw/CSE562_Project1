//
//  AgenticAiAPP_Tests.swift
//  AgenticAiAPP_Tests
//
//  Created by Jacob Edelson on 4/7/25.
//

import Testing

struct AgenticAiAPP_Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
